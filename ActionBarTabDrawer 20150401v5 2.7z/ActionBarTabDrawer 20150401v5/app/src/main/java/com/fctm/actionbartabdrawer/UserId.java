package com.fctm.actionbartabdrawer;

/**
 * Created by stduser on 2015/3/19.
 */
public class UserId
{
    public final static int type0 = 0;//雇主身份
    public final static int type1 = 1;//勞工身份

}
