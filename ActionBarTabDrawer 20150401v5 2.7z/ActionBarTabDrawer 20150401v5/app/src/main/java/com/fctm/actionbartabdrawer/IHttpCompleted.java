package com.fctm.actionbartabdrawer;
/**
 * Created by Red on 2015/3/28.
 */


/**
 * Created by aaron on 3/26/15.
 */
public interface IHttpCompleted
{
    public void doNotify(String result);
    public void doError(int resID);
}
